package penguin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class products_data {

    public static ObservableList<products> getProducts() {
        DBConnect connect = new DBConnect();
        Connection connectDBS = connect.getConnection();

        ObservableList<products> list = FXCollections.observableArrayList();
        try {
            PreparedStatement pre_statement = connectDBS.prepareStatement("SELECT * FROM products_table");
            ResultSet pro_result = pre_statement.executeQuery();

            while (pro_result.next()) {
                list.add(new products(
                        Integer.parseInt(pro_result.getString("product_id")),
                        pro_result.getString("products_name"),
                        pro_result.getString("products_category"),
                        Double.parseDouble(pro_result.getString("products_price")),
                        Integer.parseInt(pro_result.getString("products_stock")),
                        LocalDate.parse(pro_result.getString("date_assessed"))
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
