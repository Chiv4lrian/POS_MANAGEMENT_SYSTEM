package penguin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Objects;
import java.util.ResourceBundle;

import static penguin.MainApp.stage1;

public class MainController implements Initializable {
    private boolean toggle = false;
    //ChoiceBox Arrays
    ObservableList<String> choicebox1_list = FXCollections.observableArrayList("Beverages","Condiments");
    ObservableList<String> choicebox2_list = FXCollections.observableArrayList("₱1 - ₱5", "₱6 - ₱10", "₱11 - ₱20","₱21 - ₱50","₱51 - ₱100", "₱101 - ₱200");
    ObservableList<String> choicebox3_list = FXCollections.observableArrayList("Lowest","Highest");
    //ChoiceBox Arrays End

    //menu_butts
    @FXML
    private Button inventory_butt;
    @FXML
    private Button pos_butt;
    @FXML
    private Button report_butt;
    @FXML
    private Button user_butt;
    //menu_butts_end

    //buttons_back_main
    @FXML
    private Button back_to_wan;
    @FXML
    private Button back_to_wan2;
    @FXML
    private Button back_to_wan3;
    @FXML
    private Button back_to_wan4;
    //buttons_back_main

    @FXML
    private Pane main_pane;
    @FXML
    private AnchorPane inventory_pane;
    @FXML
    private AnchorPane pos_pane;
    @FXML
    private AnchorPane reports_pane;
    @FXML
    private AnchorPane user_pane;
    @FXML
    private Button log_out;
    @FXML
    private Label account_name;
    @FXML
    private Label account_number;
    //choicebox
    @FXML
    private ChoiceBox<String> choicebox1;
    @FXML
    private ChoiceBox<String> choicebox2;
    @FXML
    private ChoiceBox<String> choicebox3;
    @FXML
    private ChoiceBox<String> choicebox4;
    @FXML
    private ChoiceBox<String> choicebox5;
    @FXML
    private ChoiceBox<String> choicebox6;


    //choicebox_end

    //inventory buttons/panes/choicebox
    @FXML
    private Button add_product;
    @FXML
    private Button back_to_invent;
    @FXML
    private Button back_to_invent2;
    @FXML
    private Button submit_butt;
    /*
    @FXML
    private Button submit_butt2;
    */
    @FXML
    private Button edit_butt;
    @FXML
    private Pane add_pane;
    @FXML
    private Pane edit_pane;

    //invent buttons end
    //ButtonsOnActions
     public void main_buttAction(){
         inventory_butt.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
             main_pane.setVisible(false);
             inventory_pane.setVisible(true);
         });
         pos_butt.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
             main_pane.setVisible(false);
             pos_pane.setVisible(true);
         });
         report_butt.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
             main_pane.setVisible(false);
             reports_pane.setVisible(true);
         });
         user_butt.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
             main_pane.setVisible(false);
             user_pane.setVisible(true);
         });
         //logout
         log_out.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
             try {
                 Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("penglog.fxml")));
                 Scene scene = new Scene(root);
                 stage1.setResizable(false);
                 stage1.setMaximized(false);
                 stage1.setScene(scene);
                 stage1.show();
             } catch (IOException ex) {
                 throw new RuntimeException(ex);
             }
         });
    }
    public void main_buttAction2() {
        back_to_wan.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            main_pane.setVisible(true);
            inventory_pane.setVisible(false);
        });
        back_to_wan2.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            main_pane.setVisible(true);
            pos_pane.setVisible(false);
        });
        back_to_wan3.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            main_pane.setVisible(true);
            reports_pane.setVisible(false);
        });
        back_to_wan4.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            main_pane.setVisible(true);
            user_pane.setVisible(false);
        });
    }
    //invent_buttons
    public void invent_buttons(){
        add_product.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> add_pane.setVisible(true));
        back_to_invent.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> add_pane.setVisible(false));
        back_to_invent2.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> edit_pane.setVisible(false));
        show_products.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            toggle = !toggle;
            products_table.setDisable(toggle);
        });
        edit_butt.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> edit_pane.setVisible(true));
    }

    //ButtonsOnActions_End

        //TABLES_ALL_FUNCTIONS
        @FXML
        private TableView<products> products_table;
    @FXML
    private TableColumn<products, Integer> productID_col;
    @FXML
    private TableColumn<products, String> productname_col;
    @FXML
    private TableColumn<products, String> category_col;
    @FXML
    private TableColumn<products, Double> price_col;
    @FXML
    private TableColumn<products, Integer> stock_col;
    @FXML
    private TableColumn<products, LocalDate> date_col;
    @FXML
    private TextField txt_productid;
    @FXML
    private TextField txt_productname;
    @FXML
    private TextField txt_category;
    @FXML
    private TextField txt_price;
    @FXML
    private TextField txt_stock;
    @FXML
    private TextField txt_date;
    @FXML
    private Button show_products;
    @FXML
    private ObservableList<products> pro_list;
    @FXML
    private int index = -1;
    @FXML
    private DBConnect connects = new DBConnect();
    @FXML
    private Connection con_pro = connects.getConnection();


    public void printId() {
        String query_sql = "SELECT MAX(product_id) + 1 AS next_proid FROM products_table";
        try {
            PreparedStatement autops = con_pro.prepareStatement(query_sql);
            ResultSet next_id = autops.executeQuery();
            if (next_id.next()) {
                txt_productid.setText(String.valueOf(next_id.getInt("next_proid")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addProducts() {
        String sql = "INSERT INTO products_table(products_name, products_category, products_price, products_stock, date_assessed) VALUES(?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = con_pro.prepareStatement(sql);
            ps.setString(1, txt_productname.getText());
            ps.setString(2, txt_category.getText());
            ps.setDouble(3, Double.parseDouble(txt_price.getText()));
            ps.setInt(4, Integer.parseInt(txt_stock.getText()));
            java.sql.Date sqlDate = java.sql.Date.valueOf(LocalDate.now());
            ps.setDate(5, sqlDate);
            ps.execute();
            submit_butt.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> add_pane.setVisible(false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        productID_col.setCellValueFactory(new PropertyValueFactory<>("id"));
        productname_col.setCellValueFactory(new PropertyValueFactory<>("name"));
        category_col.setCellValueFactory(new PropertyValueFactory<>("category"));
        price_col.setCellValueFactory(new PropertyValueFactory<>("price"));
        stock_col.setCellValueFactory(new PropertyValueFactory<>("stock"));
        date_col.setCellValueFactory(new PropertyValueFactory<>("date"));

        pro_list = products.getProducts();
        products_table.setItems(pro_list);

        choicebox1.setItems(choicebox1_list);
        choicebox1.setValue("CATEGORIES");
        choicebox2.setItems(choicebox2_list);
        choicebox2.setValue("PRICE");
        choicebox3.setItems(choicebox3_list);
        choicebox3.setValue("SORT");
        choicebox4.setItems(choicebox1_list);
        choicebox4.setValue("CATEGORIES");
        choicebox5.setItems(choicebox2_list);
        choicebox5.setValue("PRICE");
        choicebox6.setItems(choicebox3_list);
        choicebox6.setValue("SORT");
    }


    /*
    public void edit() {
        try {
            int id = Integer.parseInt(txt_productid.getText());
            String newName = txt_productname.getText();
            String newCategory = txt_category.getText();
            double newPrice = Double.parseDouble(txt_price.getText());
            int newStock = Integer.parseInt(txt_stock.getText());

            // Update the database
            String sql = "UPDATE products_table SET products_name=?, products_category=?, products_price=?, products_stock=? WHERE product_id=?";
            PreparedStatement ps = con_pro.prepareStatement(sql);
            ps.setString(1, newName);
            ps.setString(2, newCategory);
            ps.setDouble(3, newPrice);
            ps.setInt(4, newStock);
            ps.setInt(5, id);
            ps.executeUpdate();

            // Update the data in the GUI
            products updatedProduct = pro_list.get(index);
            updatedProduct.setName(newName);
            updatedProduct.setCategory(newCategory);
            updatedProduct.setPrice(newPrice);
            updatedProduct.setStock(newStock);
            products_table.refresh(); // Refresh the TableView

        } catch (Exception e) {
            e.printStackTrace();
        }
        }
        }
     */
}



