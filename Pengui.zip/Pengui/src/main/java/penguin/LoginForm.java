package penguin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class LoginForm {

    @FXML
    private Button login_butt;
    @FXML
    private Button exit_butt;
    @FXML
    private Label msg_null;
    @FXML
    private TextField user;
    @FXML
    private TextField password;
    @FXML
    private ImageView user_logo;
    @FXML
    private ImageView pass_logo;
    @FXML
    private Pane login_form;

    private Stage stage;
    private Scene scene;
    private Parent root;

    public void initialize() {
        user.setOnKeyPressed(this::handleKeyPress);
        password.setOnKeyPressed(this::handleKeyPress);
    }

    public void handleKeyPress(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            login_buttOnAction(new ActionEvent());
        }
    }

    // img when click focus to textfield
    public void focus() {
        user_logo.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            user.requestFocus();
        });
        pass_logo.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            password.requestFocus();
        });
    }

    // login_butt on action
    public void login_buttOnAction(ActionEvent event) {
        if (user.getText().isBlank() && password.getText().isBlank()) {
            msg_null.setVisible(true);
            msg_null.setText("Don't Leave it Blank");
        } else if (user.getText().isBlank() || password.getText().isBlank()) {
            if (user.getText().isBlank()) {
                msg_null.setVisible(true);
                msg_null.setText("Enter Your Username");
            } else {
                msg_null.setVisible(true);
                msg_null.setText("Enter Your Password");
            }
        }
        else {
            try {
                if (validatelogin()) {
                    String username = user.getText();

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("main_app.fxml"));
                    Parent root = loader.load();
                    MainController con2 = loader.getController();
                    //con2.displayName(username);
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.setMaximized(true);
                    stage.setResizable(true);
                    stage.show();
                } else {
                    if (confirmRetry() == true) {
                        Stage stage = (Stage) exit_butt.getScene().getWindow();
                        stage.close();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public boolean validatelogin(){
        DBConnect connectNow = new DBConnect();
        Connection connectDB = connectNow.getConnection();

        String verifylogin = "SELECT count(1) from account WHERE Username = '"+user.getText()+"' AND Password = '"+password.getText()+"'";

        try{
            Statement statement = connectDB.createStatement();
            ResultSet query_result = statement.executeQuery(verifylogin);

            while(query_result.next()){
                if(query_result.getInt(1) == 1){
                    return true;
                }
                else {
                    MainApp.stage1.close();
                    return false;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // exit button
    public void exit_buttOnAction(ActionEvent e) {
        Stage stage = (Stage) exit_butt.getScene().getWindow();
        stage.close();
    }
    private boolean confirmRetry() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Login Failed");
        alert.setHeaderText("Incorrect username or password");
        alert.setContentText("Do you want to try again?");

        ButtonType retryButton = new ButtonType("Retry", ButtonBar.ButtonData.YES);
        ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(retryButton, exitButton);

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == retryButton) {
            return false;
        } else {
            return true;
        }
    }
}
