package penguin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class products {
    private int id;
    private double price;
    private int stock;
    private String name;
    private String category;
    private LocalDate date;

    public products(int id, String name, String category, double price, int stock, LocalDate date) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
        this.date = date;
    }

    public static ObservableList<products> getProducts() {
        ObservableList<products> productList = FXCollections.observableArrayList();

        // Establish a database connection (assuming you have a DBConnect class)
        DBConnect connect = new DBConnect();
        Connection connection = connect.getConnection();

        if (connection != null) {
            // Define your SQL query
            String query = "SELECT * FROM products_table";

            try {
                PreparedStatement statement = connection.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    int id = resultSet.getInt("product_id");
                    String name = resultSet.getString("products_name");
                    String category = resultSet.getString("products_category");
                    double price = resultSet.getDouble("products_price");
                    int stock = resultSet.getInt("products_stock");
                    LocalDate date = resultSet.getDate("date_assessed").toLocalDate();
                    productList.add(new products(id, name, category, price, stock, date));
                }

                // Close the resources
                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                // Close the database connection
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.err.println("Failed to establish a database connection.");
        }

        return productList;
    }

    public int getId() {
        return id;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public LocalDate getDate() {
        return date;
    }
}
