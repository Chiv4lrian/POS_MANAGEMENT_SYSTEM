package penguin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SalesData {

    public static ObservableList<Sale> getSales() {
        DBConnect connect = new DBConnect();
        Connection connectDBS = connect.getConnection();

        ObservableList<Sale> list = FXCollections.observableArrayList();
        try {
            PreparedStatement pre_statement = connectDBS.prepareStatement("SELECT * FROM sales");
            ResultSet saleResult = pre_statement.executeQuery();

            while (saleResult.next()) {
                list.add(new Sale(
                        Integer.parseInt(saleResult.getString("sale_id")),
                        Integer.parseInt(saleResult.getString("product_id")),
                        LocalDate.parse(saleResult.getString("sale_date")),
                        Integer.parseInt(saleResult.getString("sale_quantity")),
                        Double.parseDouble(saleResult.getString("sale_price"))
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


}
