package penguin;

import java.time.LocalDate;

public class Sale {
    private int id;
    private int productId;
    private LocalDate saleDate;
    private int quantity;
    private double price;

    public Sale(int id, int productId, LocalDate saleDate, int quantity, double price) {
        this.id = id;
        this.productId = productId;
        this.saleDate = saleDate;
        this.quantity = quantity;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public int getProductId() {
        return productId;
    }

    public LocalDate getSaleDate() {
        return saleDate;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }
}
